"""Important Notes:
This plugin uses Google Cloud Text to Speech service.
Read more at: https://cloud.google.com/text-to-speech

To work with this plugin, you need to:
1) Create a credential key and download it.  Read for details at https://cloud.google.com/text-to-speech/docs/before-you-begin
2) Rename the credential key file to "credentials_GoogleCloudTextToSpeech.json"
3) Place the credential key file "credentials_GoogleCloudTextToSpeech.json" in UniqueBibleApp folder.
"""

import config, os
from install.module import *

# Install essential module if it is absent
try:
    from google.cloud import texttospeech
    moduleInstalled = True
except:
    moduleInstalled = False
if not moduleInstalled:
    installmodule("--upgrade google-cloud-texttospeech")

if config.pluginContext:
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = os.path.join(os.getcwd(), "credentials_GoogleCloudTextToSpeech.json")

    # Modified from ource: https://cloud.google.com/text-to-speech/docs/create-audio-text-client-libraries#client-libraries-install-python
    """Synthesizes speech from the input string of text or ssml.
    Make sure to be working in a virtual environment.

    Note: ssml must be well-formed according to:
        https://www.w3.org/TR/speech-synthesis/
    """
    from google.cloud import texttospeech

    # Instantiates a client
    client = texttospeech.TextToSpeechClient()

    # Set the text input to be synthesized
    synthesis_input = texttospeech.SynthesisInput(text=config.pluginContext)

    # Build the voice request, select the language code ("yue-HK") and the ssml
    # voice gender ("neutral")
    voice = texttospeech.VoiceSelectionParams(
        language_code="yue-HK", ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL
    )

    # Select the type of audio file you want returned
    audio_config = texttospeech.AudioConfig(
        audio_encoding=texttospeech.AudioEncoding.MP3
    )

    # Perform the text-to-speech request on the text input with the selected
    # voice parameters and audio file type
    response = client.synthesize_speech(
        input=synthesis_input, voice=voice, audio_config=audio_config
    )

    # The response's audio_content is binary.
    tempFolder = os.path.join(os.getcwd(), config.musicFolder, "tmp")
    if not os.path.isdir(tempFolder):
        os.makedirs(tempFolder, exist_ok=True)
    outputFile = os.path.join(tempFolder, "text_to_Cantonese.mp3")
    with open(outputFile, "wb") as out:
        # Write the response to the output file.
        out.write(response.audio_content)
        print('Audio content written to file "{0}"'.format(outputFile))

    # Play sound file with built-in VLC player.
    config.mainWindow.textCommandChanged("VLC:::{0}".format(outputFile), "main")

else:
    config.contextSource.messageNoSelection()
