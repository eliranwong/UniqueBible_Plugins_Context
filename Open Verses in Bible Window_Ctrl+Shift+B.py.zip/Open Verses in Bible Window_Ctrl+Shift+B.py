import config

config.contextSource.displayVersesInBibleWindow()
