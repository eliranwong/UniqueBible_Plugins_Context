import config

presentationParser = config.presentationParser

config.presentationParser = False

if config.pluginContext:
    config.mainWindow.runTextCommand("SCREEN:::{0}".format(config.pluginContext))
else:
    config.contextSource.messageNoSelection()

config.presentationParser = presentationParser
