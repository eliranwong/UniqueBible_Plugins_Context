import config
from util.BibleVerseParser import BibleVerseParser

window = "BIBLE"
bible = "KJV"
ref = BibleVerseParser(config.parserStandarisation).bcvToVerseReference(config.mainB, config.mainC, config.mainV)
config.mainWindow.runTextCommand("{0}:::{1}:::{2}".format(window, bible, ref))
