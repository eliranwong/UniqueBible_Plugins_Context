import config

config.contextSource.displayVersesInNewWindow()
